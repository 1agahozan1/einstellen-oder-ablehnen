alt=int(input("Wie alt sind Sie"))
abschlussnote=int(input("Abschlussnote"))
if 20<=alt<=50:
  if 80<abschlussnote<=100:
    print("einstellen")
  else:
    print("ablehnen")
else:
  print("ablehnen")
    
  
   
      
      
      
      
   